function SprintBox(index){
    console.log(index)
    var no=index;
    console.log("no"+JSON.stringify(no.index))

    return<>
     <div className="sprint">
              <div> <label>Sprint {no.index}</label></div>
              
               <div className="sprint1">
               
                   {/* <label id="todo">ToDo</label><br></br>
                   <label id="inprogress">InProgress</label><br></br>
                   <label id="review">Review</label><br></br>
                   <label id="complete">Completed</label> */}
               </div>
             </div>
    </>
};
export default SprintBox;